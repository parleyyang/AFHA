function x = uhadtr2(x, varargin)

x = hadtr(hadtr(x, varargin{:}).', varargin{:}).' / sqrt(numel(x));

end
