function x = uhadtr(x, varargin)

x = hadtr(x, varargin{:})/sqrt(size(x,1));

end
