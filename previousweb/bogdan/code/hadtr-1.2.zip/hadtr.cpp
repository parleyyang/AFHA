/*
Hadamard Transform with Sequency or Natural ordering and 
multi-core/CPU support (via OpenMP), and complex values support.

A lot faster than Matlab's fwht(), e.g i7-3770K @ 4.9 GHz on Windows:

- 2048^2-by-1 vector:     0.118 sec (sequency) and 0.094  sec (natural)
- 2048-by-2048 matrix:    0.011 sec (sequency) and 0.0098 sec (natural)
- 16384-by-16384 matrix:  0.70  sec (sequency) and 0.61   sec (natural)

The code runs single-threaded on vectors, but multi-threaded on matrices. This
is obvious from above. Comparing to Matlab's fwht() on same data:

- fwht(), 2048^2-by-1:    25.8s (sequency) and 30.0s (natural) - 218x slower
- fwht(), 2048-by-2048:   0.91s (sequency) and 0.92s (natural) -  83x slower
- fwht(), 16384-by-16384: 117s  (sequency) and 121s  (natural) - 170x slower

The code for sequential natural ordered transform for real values was inspired
by the "hadamardc" contribution by Peter Stobbe (Caltech), stobbe@caltech.edu
http://bit.ly/1j1hJm9


Compilation
===========

Make sure you have the OpenMP library. So far tested with the following:
- Windows: VS2012 and MingW with GCC 4.6, 4.7, 4.8, 4.9
- Linux: GCC 4.6, 4.7, 4.8, 4.9
- MacOSX: GCC 4.9 (gcc-mp-4.9 (MacPorts gcc49 4.9-20140416_0) 4.9.0 20140416 (prerelease))

GCC: mex CXXFLAGS="\$CXXFLAGS -fopenmp" -DDEFINEUNIX -largeArrayDims -lgomp hadtr.cpp
VS:  mex COMPFLAGS="$COMPFLAGS /openmp" -largeArrayDims hadtr.cpp

If you don't have OpenMP then just comment out the #pragma lines in the code
but know that this will make slow for matrices (vectors are not affected).

To compile on R2013a on MacOSX with OpenMP is trickier since Xcode's Clang was
not compiled with OpenMP support. There are instructions on how to compile a
Clang version with OpenMP awaresupport here: http://stackoverflow.com/a/21789869
(official but manual instructions here: http://clang-omp.github.io) which will
get you a 'clang2' executable to use (the system’s Clang is not affected).

The solution I opted for was to install the true GCC from Macports:

sudo port install gcc49

And then alter mexopts.sh to use gcc-mp-49 instead of Xcode's Clang. To do this
first type 'mex -setup' in Matlab and choose the mexopts.sh option (usually the
first). Then edit ~/.matlab/r2013a/mexopts.sh (make a backup first) and replace
the entire "maci64)" section with the following:

        maci64)
#----------------------------------------------------------------------------
            PATH="/opt/local/bin:/opt/local/sbin:$PATH"
            # StorageVersion: 1.0
            # CkeyName: GNU C
            # CkeyManufacturer: GNU
            # CkeyLanguage: C
            # CkeyVersion:
            # CkeyLinkerName: GNU ld
            # CkeyLinkerVersion:
            CC='gcc-mp-4.9'
            CFLAGS='-ansi -D_GNU_SOURCE'
            CFLAGS="$CFLAGS  -fexceptions"
            CFLAGS="$CFLAGS -fPIC -fno-omit-frame-pointer -pthread"
            CLIBS="$RPATH $MLIBS -lm"
            COPTIMFLAGS='-O -DNDEBUG'
            CDEBUGFLAGS='-g'
            CLIBS="$CLIBS -lstdc++"
#
            # C++keyName: GNU C++
            # C++keyManufacturer: GNU
            # C++keyLanguage: C++
            # C++keyVersion:
            # C++keyLinkerName: GNU ld
            # C++keyLinkerVersion:  
            CXX='g++-mp-4.9'
            CXXFLAGS='-ansi -D_GNU_SOURCE'
            CXXFLAGS="$CXXFLAGS -fPIC -fno-omit-frame-pointer -pthread"
            CXXLIBS="$RPATH $MLIBS -lm"
            CXXOPTIMFLAGS='-O -DNDEBUG'
            CXXDEBUGFLAGS='-g'
#
            # FortrankeyName: gfortran
            # FortrankeyManufacturer: GNU
            # FortrankeyLanguage: Fortran
            # FortrankeyVersion:
            # FortrankeyLinkerName: GNU ld
            # FortrankeyLinkerVersion:  
#
            FC='gfortran'
            FFLAGS='-fexceptions -fbackslash'
            FFLAGS="$FFLAGS -fPIC -fno-omit-frame-pointer"
            FLIBS="$RPATH $MLIBS -lm"
            FOPTIMFLAGS='-O'
            FDEBUGFLAGS='-g'
            LD="$COMPILER"
            LDEXTENSION='.mexmaci64'
            LDFLAGS="-pthread -shared"
            LDOPTIMFLAGS='-O'
            LDDEBUGFLAGS='-g'
            POSTLINK_CMDS=':'
#----------------------------------------------------------------------------
            ;;

Usage
=====

Y = hadtr(X) is the Sequency ordered (also called Walsh ordered) Hadamard
transform of X. X can be a vector (both row and column are ok) or a matrix,
and can be either real or complex. If X is a matrix, the transform will be 
applied column wise and use parallel threads. If you want a unitary transform
then just divide by sqrt(N) where N is the vector length (if X is a vector) or
the number of rows (if X is a matrix). You can implement a 2D transform by
doing hadtr(hadtr(X).').'. For a unitary 2D transform just divide by N.

Y = hadtr(X,1) is the same as above.

Y = hadtr(x,2) is the natural ordered transform (also called Hadamard ordered)
of X. This is equivalent to fwht(X,[],'hadamard')*N. The rest is the same as
above.

The transform is symmetric, i.e. the inverse transform is the same - but you
need to divide by N as it's not unitary by default (see above).

The natural ordered hadamard code uses exactly N*log2(N) additions/
subtractions. For the sequency ordered code, an extra 2N permutations are
needed (bit-reverse and gray code). The speed penalty in most cases is
negligible as the code is highly optimized for speed and multi-threading.


Todo
====

The sequency ordered transform can be implemented without any prior/post
permutations, as it's done in fwht(). Nnot sure about speed though.


Changelog
=========

v1.2 May 2014 - added noted on MacOSX compilation
v1.1 Jan 2014 - added support for complex values

Bogdan Roman, Cambridge University, abr28@cam.ac.uk

*/

#include "mex.h"
#include <omp.h>
//#include <memory.h>

typedef long long index_t;
typedef index_t (*fptr_bitreverse)(index_t);

// inspired from http://bit.ly/1k4jYVV
static const unsigned char bitreverse_lut[] = 
{
	0x00, 0x80, 0x40, 0xC0, 0x20, 0xA0, 0x60, 0xE0, 0x10, 0x90, 0x50, 0xD0, 0x30, 0xB0, 0x70, 0xF0, 
	0x08, 0x88, 0x48, 0xC8, 0x28, 0xA8, 0x68, 0xE8, 0x18, 0x98, 0x58, 0xD8, 0x38, 0xB8, 0x78, 0xF8, 
	0x04, 0x84, 0x44, 0xC4, 0x24, 0xA4, 0x64, 0xE4, 0x14, 0x94, 0x54, 0xD4, 0x34, 0xB4, 0x74, 0xF4, 
	0x0C, 0x8C, 0x4C, 0xCC, 0x2C, 0xAC, 0x6C, 0xEC, 0x1C, 0x9C, 0x5C, 0xDC, 0x3C, 0xBC, 0x7C, 0xFC, 
	0x02, 0x82, 0x42, 0xC2, 0x22, 0xA2, 0x62, 0xE2, 0x12, 0x92, 0x52, 0xD2, 0x32, 0xB2, 0x72, 0xF2, 
	0x0A, 0x8A, 0x4A, 0xCA, 0x2A, 0xAA, 0x6A, 0xEA, 0x1A, 0x9A, 0x5A, 0xDA, 0x3A, 0xBA, 0x7A, 0xFA,
	0x06, 0x86, 0x46, 0xC6, 0x26, 0xA6, 0x66, 0xE6, 0x16, 0x96, 0x56, 0xD6, 0x36, 0xB6, 0x76, 0xF6, 
	0x0E, 0x8E, 0x4E, 0xCE, 0x2E, 0xAE, 0x6E, 0xEE, 0x1E, 0x9E, 0x5E, 0xDE, 0x3E, 0xBE, 0x7E, 0xFE,
	0x01, 0x81, 0x41, 0xC1, 0x21, 0xA1, 0x61, 0xE1, 0x11, 0x91, 0x51, 0xD1, 0x31, 0xB1, 0x71, 0xF1,
	0x09, 0x89, 0x49, 0xC9, 0x29, 0xA9, 0x69, 0xE9, 0x19, 0x99, 0x59, 0xD9, 0x39, 0xB9, 0x79, 0xF9, 
	0x05, 0x85, 0x45, 0xC5, 0x25, 0xA5, 0x65, 0xE5, 0x15, 0x95, 0x55, 0xD5, 0x35, 0xB5, 0x75, 0xF5,
	0x0D, 0x8D, 0x4D, 0xCD, 0x2D, 0xAD, 0x6D, 0xED, 0x1D, 0x9D, 0x5D, 0xDD, 0x3D, 0xBD, 0x7D, 0xFD,
	0x03, 0x83, 0x43, 0xC3, 0x23, 0xA3, 0x63, 0xE3, 0x13, 0x93, 0x53, 0xD3, 0x33, 0xB3, 0x73, 0xF3, 
	0x0B, 0x8B, 0x4B, 0xCB, 0x2B, 0xAB, 0x6B, 0xEB, 0x1B, 0x9B, 0x5B, 0xDB, 0x3B, 0xBB, 0x7B, 0xFB,
	0x07, 0x87, 0x47, 0xC7, 0x27, 0xA7, 0x67, 0xE7, 0x17, 0x97, 0x57, 0xD7, 0x37, 0xB7, 0x77, 0xF7, 
	0x0F, 0x8F, 0x4F, 0xCF, 0x2F, 0xAF, 0x6F, 0xEF, 0x1F, 0x9F, 0x5F, 0xDF, 0x3F, 0xBF, 0x7F, 0xFF
};

inline index_t bitreverse32 (index_t v)
{
	return
		(bitreverse_lut[v         & 0xff] << 24) | 
		(bitreverse_lut[(v >> 8)  & 0xff] << 16) | 
		(bitreverse_lut[(v >> 16) & 0xff] << 8 ) |
		(bitreverse_lut[(v >> 24) & 0xff]);
}

inline index_t bitreverse24 (index_t v)
{
	return
		(bitreverse_lut[v         & 0xff] << 16) |
		(bitreverse_lut[(v >> 8)  & 0xff] << 8 ) | 
		(bitreverse_lut[(v >> 16) & 0xff]      );
}

inline index_t bitreverse16 (index_t v)
{
	return
		(bitreverse_lut[v        & 0xff] << 8) | 
		(bitreverse_lut[(v >> 8) & 0xff]     ); 
}

inline index_t bitreverse8 (index_t v)
{
	return bitreverse_lut[v & 0xff];
}

inline index_t graypermute (index_t v)
{
	return (v >> 1) ^ v;
}

class HADTR
{
public:
	typedef  void (HADTR::*fptr_order)(double* y, index_t len);

	bool iscomplex;
	bool isvector;
	fptr_bitreverse bitreverse;		// Pointer to bit-reversal function
									//  different functions to optimize speed
	fptr_order order;				// Pointer to sequency ordering function
									//  different functions for single/multi-threaded
	index_t bits;					// Nr of bits in length, needed to adjust
									//  Bit-reversal output to correct binary length
	index_t len;					// length of transform, power of 2

	HADTR (int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) :
		order(&HADTR::order_natural)
	{
		double *xr, *yr, *xi, *yi;
		index_t m, n;

		if (nrhs < 1 || nlhs > 1)
			mexErrMsgTxt("One output and one input required.");

		iscomplex = mxIsComplex(prhs[0]);

		m = mxGetM(prhs[0]);
		n = mxGetN(prhs[0]);
		len = (m == 1) ? n : m;
		check_len(len); // also compute nr of bits (used in bit-reversal)
		isvector = m == 1 || n == 1;

		// sequency requested or omitted (default)
		if (nrhs == 1 || *mxGetPr(prhs[1]) < 2)
		{
			if (isvector)
				order = &HADTR::order_sequency_omp;
			else
				order = &HADTR::order_sequency_single;

			if		(bits <= 8 )	{ bits =  8 - bits; bitreverse = &bitreverse8;  }
			else if (bits <= 16)	{ bits = 16 - bits; bitreverse = &bitreverse16; }
			else if (bits <= 24)	{ bits = 24 - bits; bitreverse = &bitreverse24; }
			else if (bits <= 32)	{ bits = 32 - bits; bitreverse = &bitreverse32; }
			else mexErrMsgTxt("Number of elements exceeds 2^32-1.");
		}

		if (iscomplex)
		{
			plhs[0] = mxCreateDoubleMatrix(m, n, mxCOMPLEX);
			xr = mxGetPr(prhs[0]);
			yr = mxGetPr(plhs[0]);
			xi = mxGetPi(prhs[0]);
			yi = mxGetPi(plhs[0]);

			if (isvector)
			{
				hadamard_vector(yr, xr, len);
				hadamard_vector(yi, xi, len);
			}
			else
			{
				index_t j;
				//if (dimension == 2)
				//{
				//	#pragma omp parallel for shared(m, n, y, x) private(j) 
				//	for (j=0; j<m; j+=1)
				//		hadamard_apply_row(y + j, x + j, n, m);
				//}
				//else
				//{
				index_t numel = n*m;
				#pragma omp parallel for shared(numel, m, yr, xr, yi, xi) private(j) 
				for (j=0; j<numel; j+=m)
				{
					hadamard_vector(yr + j, xr + j, m);
					hadamard_vector(yi + j, xi + j, m);
				}
				//}
			}
		}
		else
		{
			plhs[0] = mxCreateDoubleMatrix(m, n, mxREAL);
			xr = mxGetPr(prhs[0]);
			yr = mxGetPr(plhs[0]);

			if (isvector)
				hadamard_vector(yr, xr, len);
			else
			{
				index_t j;
				//if (dimension == 2)
				//{
				//	#pragma omp parallel for shared(m, n, y, x) private(j) 
				//	for (j=0; j<m; j+=1)
				//		hadamard_apply_row(y + j, x + j, n, m);
				//}
				//else
				//{
				index_t numel = n*m;
				#pragma omp parallel for shared(numel, m, yr, xr) private(j) 
				for (j=0; j<numel; j+=m)
					hadamard_vector(yr + j, xr + j, m);
				//}
			}
		}
	}

	inline void order_natural (double *y, index_t len)
	{
	}

	// Single threaded sequency (gray + bit-reversal).
	// Use this if already multi-threading.
	inline void order_sequency_single (double *y, index_t len)
	{
		index_t j;
		// Don't use mxMalloc(), it crashes (no time to investigate)
		// Don't try to preallocate perm since this function is called within
		// an OpenMP for loop.
		double *perm = new double[len];
		//memcpy(perm, y, len);
		for (j=1; j<len; ++j)
			perm[j] = y[j];
		for (j=1; j<len; ++j)
			y[j] = perm[bitreverse(graypermute(j)) >> bits];
		delete[] perm;
	}

	// Multi-threaded sequency (gray + bit-reversal).
	// Use if not already multi-threading, typically if X is a
	// vector, to speed up the sequency permutation
	// Do *not* use when X is a matrix. That's already parallelized.
	inline void order_sequency_omp (double *y, index_t len)
	{
		index_t j;
		// Don't use mxMalloc(), it crashes (no time to investigate).
		double *perm = new double[len];
		#pragma omp parallel for shared(len, perm, y) private(j) 
		for (j=1; j<len; ++j)
			perm[j] = y[j];
		#pragma omp parallel for shared(len, perm, y) private(j) 
		for (j=1; j<len; ++j)
			y[j] = perm[bitreverse(graypermute(j)) >> bits];
		delete[] perm;
	}

	// Enable the sequency flag when X is a matrix as that's parallelized
	// and you get better performance doing the permutation here then after
	// the whole matrix is transformed (racing issues).
	void hadamard_vector(double *y, double *x, index_t len)
	{
		index_t bit, j, k;
		double temp;

		for (j = 0; j < len; j+=2)
		{
			k = j+1;
			y[j] = x[j] + x[k];
			y[k] = x[j] - x[k];
		}

		for (bit=2; bit<len; bit<<=1)
		{
			for (j=0; j<len; j+=1)
			{
				if ((bit & j) == 0)
				{
					k = (j | bit);
					temp = y[j];
					y[j] += y[k];
					y[k] = temp - y[k];
				}
			}
		}

		// reorder to sequency, if pointer set
		(this->*order)(y, len);
	}

	/* 
	y - output
	x - input
	n - nr of columns
	m - nr of rows
	Matrix elements are column-major ordered, so walking a row must be done
	in steps of m, which is very slow since memory is not accessed linearly.
	Much better performance is obtained by transposing the matrix first ... 
	
	Hence, don't use this function. It's left here only for reference.

	TODO: Some speedup can be obtained by adding inner for loops to perform all the
	operations on whole columns, rather than single elements.
	*/
	void hadamard_matrix_row(double *y, double *x, index_t n, index_t m)
	{
		index_t bit, j, k, jm;
		double temp;

		for (j = 0; j < n*m; j+=(m<<1))
		{
			k = j+m;
			y[j] = x[j] + x[k];
			y[k] = x[j] - x[k];
		}

		for (bit=2; bit<n; bit<<=1)
		{
			for (j=0, jm=0; j<n; j+=1, jm+=m)
			{
				if ((bit & j) == 0)
				{
					k = (j | bit) * m;
					temp = y[jm];
					y[jm] += y[k];
					y[k] = temp - y[k];
				}
			}
		}
	}

	void check_len(index_t m)
	{
		if (m <= 1)
			mexErrMsgTxt("Number of elements must be a power of 2 greater than 0.");
		bits = 0;
		while((m & 1) == 0)
		{
			bits += 1; // compute nr of bits to realign for bit-reversal
			m >>= 1;
		}
		if (m > 1)
			mexErrMsgTxt("Number of elements must be a power of 2 greater than 0.");
	}

};


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	HADTR start(nlhs, plhs, nrhs, prhs);
}
