function x = hadtr2(x, varargin)

x = hadtr(hadtr(x, varargin{:}).', varargin{:}).';

end
